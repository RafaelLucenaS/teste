# Inspiramente Online - Site de Saúde Mental

## Sobre o Projeto

O **Inspiramente Online** é um site completo focado em saúde mental e bem-estar emocional. Foi desenvolvido com React, Tailwind CSS e componentes modernos para oferecer uma experiência profissional e acolhedora aos visitantes.

## Características Principais

### 🎨 Design e Visual
- **Tema Calmo e Sereno**: Paleta de cores em tons de azul e verde que transmitem tranquilidade
- **Layout Responsivo**: Funciona perfeitamente em desktop, tablet e dispositivos móveis
- **Animações Suaves**: Efeitos de hover, transições e animações que melhoram a experiência do usuário
- **Imagens de Alta Qualidade**: Fotos cuidadosamente selecionadas relacionadas à saúde mental

### 📱 Funcionalidades Interativas
- **Modal de Artigos**: Clique em qualquer artigo para ler o conteúdo completo em um modal elegante
- **Navegação Suave**: Links do menu levam suavemente às seções correspondentes
- **Formulário de Contato**: Formulário funcional para os visitantes entrarem em contato
- **Efeitos Visuais**: Animações de respiração, gradientes e transições suaves

### 📝 Conteúdo Rico
- **3 Artigos Completos** sobre saúde mental:
  1. "Como Manter o Equilíbrio Emocional"
  2. "Guia Completo de Meditação para Iniciantes"  
  3. "A Importância do Autocuidado Diário"
- **Seções Bem Estruturadas**: Home, Sobre, Artigos, Serviços e Contato
- **Conteúdo SEO Otimizado**: Títulos, meta descrições e estrutura otimizada para buscadores

## Estrutura do Site

### Seções Principais:
1. **Header**: Navegação fixa com logo e menu
2. **Hero Section**: Apresentação principal com call-to-action
3. **Recursos**: Cards explicando os serviços oferecidos
4. **Artigos em Destaque**: Grid com os artigos principais (clicáveis)
5. **Sobre**: Informações sobre a missão do site
6. **Contato**: Formulário e informações de contato
7. **Footer**: Links organizados e informações adicionais

## Tecnologias Utilizadas

- **React 18**: Framework JavaScript moderno
- **Tailwind CSS**: Framework CSS utilitário
- **Shadcn/UI**: Componentes de interface elegantes
- **Lucide Icons**: Ícones modernos e limpos
- **Vite**: Build tool rápido e eficiente

## Como Executar o Site

### Pré-requisitos
- Node.js (versão 18 ou superior)
- npm ou pnpm

### Passos para Executar:

1. **Navegue até a pasta do projeto:**
   ```bash
   cd inspiramenteonline
   ```

2. **Instale as dependências:**
   ```bash
   pnpm install
   # ou
   npm install
   ```

3. **Execute o servidor de desenvolvimento:**
   ```bash
   pnpm run dev
   # ou
   npm run dev
   ```

4. **Acesse o site:**
   Abra seu navegador e vá para `http://localhost:5173`

### Para Build de Produção:

1. **Gere os arquivos de produção:**
   ```bash
   pnpm run build
   # ou
   npm run build
   ```

2. **Os arquivos estarão na pasta `dist/`** prontos para serem hospedados em qualquer servidor web.

## Estrutura de Arquivos

```
inspiramenteonline/
├── public/                 # Arquivos públicos
├── src/
│   ├── assets/
│   │   └── images/        # Imagens do site
│   ├── components/
│   │   ├── ui/           # Componentes base (shadcn/ui)
│   │   └── ArticleModal.jsx  # Modal dos artigos
│   ├── data/
│   │   └── articles.js   # Dados dos artigos
│   ├── App.jsx          # Componente principal
│   ├── App.css          # Estilos personalizados
│   └── main.jsx         # Ponto de entrada
├── package.json         # Dependências e scripts
└── README.md           # Esta documentação
```

## Personalização

### Alterando Cores:
As cores principais estão definidas em `src/App.css` nas variáveis CSS customizadas:
- `--primary`: Azul calmo principal
- `--secondary`: Verde suave
- `--accent`: Azul-verde relaxante

### Adicionando Novos Artigos:
1. Abra `src/data/articles.js`
2. Adicione um novo objeto ao array `articles` seguindo a estrutura existente
3. Adicione a imagem correspondente em `src/assets/images/`

### Modificando Conteúdo:
- **Textos gerais**: Edite diretamente em `src/App.jsx`
- **Artigos**: Modifique em `src/data/articles.js`
- **Estilos**: Personalize em `src/App.css`

## Hospedagem

O site pode ser hospedado em qualquer serviço de hospedagem estática:

### Opções Recomendadas:
- **Vercel**: Deploy automático via GitHub
- **Netlify**: Hospedagem gratuita com CI/CD
- **GitHub Pages**: Hospedagem gratuita para projetos públicos
- **Servidor próprio**: Qualquer servidor web (Apache, Nginx)

### Para Vercel:
1. Conecte seu repositório GitHub ao Vercel
2. O deploy será automático a cada push

### Para Netlify:
1. Faça upload da pasta `dist/` após o build
2. Configure redirects se necessário

## Suporte e Manutenção

### Atualizações Futuras:
- Adicionar mais artigos seguindo a estrutura existente
- Implementar sistema de busca nos artigos
- Adicionar newsletter ou blog
- Integrar com CMS para facilitar atualizações de conteúdo

### Problemas Comuns:
- **Imagens não carregam**: Verifique se estão na pasta `src/assets/images/`
- **Estilos não aplicam**: Certifique-se de que `import './App.css'` está presente
- **Modal não abre**: Verifique se o ArticleModal está importado corretamente

## Contato

Para dúvidas sobre o desenvolvimento ou personalização do site, entre em contato através dos canais disponíveis no próprio site.

---

**Desenvolvido com ❤️ para promover o bem-estar mental e emocional.**

